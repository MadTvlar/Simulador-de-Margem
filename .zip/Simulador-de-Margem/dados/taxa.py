taxas = {
  "doze": "De 1 à 12 Parcelas",
  "treze": "13 Parcelas",
  "quartoze": "14 Parcelas",
  "quinze": "15 Parcelas",
  "dezesseis": "16 Parcelas",
  "dezessete": "17 parcelas",
  "dezoito": "18 Parcelas",
  "dezenove": "19 Parcelas",
  "vinte": "20 Parcelas",
  "vinte_um": "21 Parcelas"
}