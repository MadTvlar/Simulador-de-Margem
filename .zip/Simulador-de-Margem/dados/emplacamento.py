#Valor do emplacamento Mensal

emplcamento = {"Janeiro": 0.03, "Fevereiro": 0.0275, "Março": 0.025,
               "Abril": 0.0225, "Maio": 0.02, "Junho": 0.0175,
               "Julho": 0.015, "Agosto": 0.0125, "Setembro": 0.01,
               "Outubro": 0.0075, "Novembro": 0.005, "Dezembro": 0.0025}