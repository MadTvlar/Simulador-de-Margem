usuarios = {
    "madson_michel": "220199",
    "louiz_migles": "123",
    "admin": "admin123",
    "gab_jogador": "admin"
}
