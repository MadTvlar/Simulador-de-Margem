
document.querySelectorAll('.card').forEach(card => {
  card.addEventListener('mouseenter', () => {
  });

  card.addEventListener('mouseleave', () => {
  });
});


document.getElementById('motos').addEventListener('click', () => {
  window.location.href = '/painel';
});
